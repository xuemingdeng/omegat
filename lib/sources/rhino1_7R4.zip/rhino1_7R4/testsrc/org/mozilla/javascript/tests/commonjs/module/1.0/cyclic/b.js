var a = require('a');
exports.b = function () {
    return a;
};
